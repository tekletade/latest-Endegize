<?php
echo 'date';
$curlHandle = curl_init('https://timeapi.io/api/Time/current/zone?timeZone=Africa/Addis_Ababa');
curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, true);

$curlResponse = curl_exec($curlHandle);
$rdata= json_decode($curlResponse);
var_dump($rdata->year." ".$rdata->month." ".$rdata->day." ".$rdata->hour." ".$rdata->minute." ".$rdata->seconds);
curl_close($curlHandle);

?>