<?php
 $db = mysqli_connect('localhost:3306','emeraldl_liner','Liner@12345678','emeraldl_liner');
 $phone = $_POST['phone'];
 $password = $_POST['password'];
 $sql = "SELECT * FROM user WHERE phone = '".$phone."' AND password = '".$password."'";
 $result = mysqli_query($db,$sql);
 $count = mysqli_num_rows($result);
 if($count == 1){
 	echo json_encode("Success");
 } 
 else{
 	echo json_encode("Error");
 }
?>