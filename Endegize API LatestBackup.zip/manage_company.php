<?php
//session_start();

header('Content-type:application/json');
$res=array();
$token = null;
  $headers = apache_request_headers();
  if(isset($headers['Authorization'])){
    if(isset($headers['Authorization'])){
      $token = $headers['Authorization'];
      if($token==null){
        $res['error']=1;
		$res['mesg']='Token is null, please login and try again';
		echo json_encode($res);
	    return;
    }
    $vd=is_jwt_valid($token, $secret = 'secretk');
    if($vd==false){
        $res['error']=1;
		$res['mesg']='Invalid credential, please login and try again';
		echo json_encode($res);
	    return;
    }
  }
}
else{
      $res['error']=1;
		$res['mesg']='Please login, and try again';
		echo json_encode($res);
	    return;
}
include("dbconnection.php");
$ret=mysqli_query($con,"SELECT distinct(cid),name,isbranch,branchname,location,date FROM company");
$comps=array();
while($num=mysqli_fetch_assoc($ret)){
	$comps[]=$num;
}
$ar=array();
$ar['compstatus']=$comps;
echo json_encode($ar);
if(isset($_POST['uid']) && isset($_POST['name']) && isset($_POST['isbranch']) && isset($_POST['branchname']))
{
	if($_POST['name']!=null && $_POST['uid']!=null){
		echo $_POST['name'];
		$cid=md5($_POST['name'].' '.$_POST['uid'].' '.$_POST['branchname']);
		echo $cid;
		$ret=mysqli_query($con,"insert into company (cid,name,isbranch,branchname,location, uid) values ('".$cid."','".$_POST['name']."','".$_POST['isbranch']."','".$_POST['branchname']."','".$_POST['location']."','".$_POST['uid']."')");
		//$ret->bind_params("sssiis",$uid,$_POST['fname'],$_POST['lname'],$_POST['pin'],$_POST['phone'],$uid);
		//$ex=$ret->execute();
		echo "insert into company (cid,name,isbranch,branchname,location, uid) values ('".$cid."','".$_POST['name']."','".$_POST['isbranch']."','".$_POST['branchname']."','".$_POST['location']."','".$_POST['uid']."')";
		var_dump($ret);
	}
}


else if(isset($_POST['uid']))
{
	$uid=$_POST['uid'];
	$ret=mysqli_query($con,"SELECT * FROM company WHERE uid='$uid'");
	$num=mysqli_fetch_array($ret);
	if($num>0)
	{
		echo $num['name'];
	}
}
else if(isset($_POST['name']) && isset($_POST['getcompany']))
{
	$phone=$_POST['name'];
	$ret=mysqli_query($con,"SELECT * FROM company WHERE name='$name'");
	$num=mysqli_fetch_array($ret);
	if($num>0)
	{
		echo $num['name'];
	}
}
else if(isset($_POST['cid']) )
{
	$uid=$_POST['cid'];
	$ret=mysqli_query($con,"SELECT * FROM company WHERE cid='$cid'");
	$num=mysqli_fetch_array($ret);
	if($num>0)
	{
		echo $num['name'];
	}
}

function base64url_encode($str) {
    return rtrim(strtr(base64_encode($str), '+/', '-_'), '=');
}
function is_jwt_valid($jwt, $secret = 'secretk') {
	// split the jwt
	$tokenParts = explode('.', $jwt);
	$header = base64_decode($tokenParts[0]);
	$payload = base64_decode($tokenParts[1]);
	$signature_provided = $tokenParts[2];
	// check the expiration time - note this will cause an error if there is no 'exp' claim in the jwt
	$expiration = json_decode($payload)->exp;
	$is_token_expired = ($expiration - time()) < 0;
	// build a signature based on the header and payload using the secret
	$base64_url_header = base64url_encode($header);
	$base64_url_payload = base64url_encode($payload);
    $signature = hash_hmac('SHA256', $base64_url_header . "." . $base64_url_payload, $secret, true);
	$base64_url_signature = base64url_encode($signature);
	// verify it matches the signature provided in the jwt
	$is_signature_valid = ($base64_url_signature === $signature_provided);
	if ($is_token_expired || !$is_signature_valid) {
		return FALSE;
	} else {
		return TRUE;
	}
}
?>