<?php
$res=array();
$token = null;
  $headers = apache_request_headers();
  if(isset($headers['Authorization'])){
    if(isset($headers['Authorization'])){
      $token = $headers['Authorization'];
      if($token==null){
        $res['error']=1; 
		$res['mesg']='Token is null, please login and try again';
		echo json_encode($res); 
	    return;
    }
    $vd=is_jwt_valid($token, $secret = 'secretk');
    if($vd==false){
        $res['error']=1;
		$res['mesg']='Invalid credential, please login and try again';
		echo json_encode($res);
	    return;
    }
  }
}
else{
      $res['error']=1;
		$res['mesg']='Please login, and try again';
		echo json_encode($res);
	    return;
}
//header('Content-type:application/json');
include "queue.php";
include "service.php";
/*
if ($_SERVER['REQUEST_METHOD'] == "POST"){
	
	$data=json_decode(file_get_contents('php://input'), true);
	if(isset($data['callqueue']) && isset($data['uid']) && isset($data['sid']) && isset($data['coordinator'])){
		$qw = new queue();
		$resp=array();
		$r=$qw->call_queue( $data['sid'],$data['uid'],$data['coordinator'],'comment','status');
		$resp['servstatus']=$r;
		echo json_encode($resp);
	}
	if( isset($data['sid']) && isset($data['token']) && isset($data['channel'])){
		$qw = new queue();
		$qw->set_queue( $data['sid'],$data['token'],$data['channel']);
	}


	if(isset($data['range_fornext']) && isset($data['sid'])){
		$qw = new queue();
		echo json_encode($qw->callForNext($data['range_fornext'],$data['sid']));
	}
}*/

if(isset($_GET['callqueue']) && isset($_GET['uid']) && isset($_GET['sid']) && isset($_GET['coordinator'])){
   // 
   
   $qw = new queue(); 
		$r=$qw->call_queue( "",$_GET['sid'],$_GET['uid'],$_GET['coordinator'],'comment','status');
		onCallQ($r);
}

//if by callqueue_qid  for issuers by qid
if(isset($_GET['callqueue_qid']) &&  isset($_GET['sid']) && isset($_GET['coordinator'])){
   // 
   $qw = new queue();
   
		$r=$qw->call_queue( $_GET['callqueue_qid'],$_GET['sid'],$_GET['uid'],$_GET['coordinator'],'comment','status');
		onCallQ($r); 
}

//if by callqueue_q1  for issuers by number
if(isset($_GET['callqueue_q1']) && isset($_GET['sid']) && isset($_GET['coordinator'])){
   // 
   $qw = new queue();
   $qid=$qw->get_queueIDbylast4qid($_GET['callqueue_q1'],$_GET['sid']);
   $qw = new queue();
		$r=$qw->call_queue( $qid,$_GET['sid'],$_GET['uid'],$_GET['coordinator'],'comment','status');
		onCallQ($r);
}

function onCallQ($r){
    
		$resp=array();
		$mesg="";
    if($r['error']==0){
		    $nextnm=$r['next'];
    	    $i_number=$r['current'];
        	$qw = new queue();
    		$r2=array();
    		$r2= $qw->remindNextwaiters($_GET['sid']);
    		echo json_encode($resp);
    		if(count($r2)>0){
    		    //var_dump($r2);
    		    for($t=0;$t<count($r2);$t++){
    		        push_notification_android($r2[$t]['ftoken'],$i_number,$nextnm,$r2[$t]['servicename']);
    		        
    		    }
    		}
    		$mesg=$r['mesg'];
		}
		else if($r['error']==1){
    		$mesg=$r['mesg']; 
		}
		$resp['callfornext']=$r;
		echo json_encode($resp);
}

if( isset($_GET['sid']) && isset($_GET['token']) && isset($_GET['channel'])){
	$qw = new queue();
	$resp=array();
	$r=$qw->set_queue( $_GET['sid'],$_GET['token'],$_GET['channel'],$_GET['ftoken']);
	
	$svc = new service();
	$r['total']=$svc->get_total_queue_byservice($_GET['sid'])['total'];
	$resp['queue_set']=$r;
	echo json_encode($resp);
}

if(isset($_GET['getQnumber']) && isset($_GET['sid'])){
	$qw = new queue();
	$resp=array();
	$resp['queue_no']=$qw->get_issuer_number($_GET['sid'],$_GET['getQnumber']);
	echo json_encode($resp);
}
if(isset($_GET['range_fornext']) && isset($_GET['sid'])){
	$qw = new queue();
	$qs=array();
	$qs['callforrange']=$qw->callForNext($_GET['range_fornext'],$_GET['sid']);
	echo json_encode($qs);
}


else if(isset($_GET['byuid']) && isset($_GET['bysid'])){
	$qw = new queue();
	
	$tod=date("Y-m-d H-i-s");
	echo $tod;
	$r=$qw->get_queue_detail($_GET['byuid'],$_GET['bysid']);
	while ($row = $r->fetch_assoc()) {
		echo '<br/>You are: '.$row['number'];
		echo '<br/>Issued on: '.$row['issue_time'];
		echo '<br/><hr/>';
	}
}
else if(isset($_GET['bysid'])){
    $qw = new queue();
    $qw->get_total_queue_byservice($_GET['bysid']);
}
if(isset($_GET['shiftQ'])){
	$qw=new queue();
	$qs=array();
	$qs['shiftdetail']=$qw->shift_queue($_GET['qid'],$_GET['uid'],$_GET['sid'],$_GET['number']);
	echo json_encode($qs);
}
if(isset($_GET['byuid'])){
	$qw = new queue();
	$qs=array();
	$qs['issuedliststatus']=$qw->get_listof_issued_queue($_GET['byuid']);
	echo json_encode($qs);
}
if(isset($_GET['getRnext'])){
	$qw = new queue();
	$qs=array();
	$qs['getnextrange']=$qw->getNextRangeQueueNumber($_GET['getRnext']);
	echo json_encode($qs);
}

if(isset($_GET['gettotal'])){
	$svc = new service();
	$qs=array();
	$qs['gettotal']=$svc->get_total_queue_byservice($_GET['gettotal'])['total'];
	echo json_encode($qs);
}

function push_notification_android($device_id,$c,$n,$service){

    //API URL of FCM
    $url = 'https://fcm.googleapis.com/fcm/send';

    /*api_key available in:
    Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/
    $api_key = 'AAAA6plpJLk:APA91bGXzMrT_ztxTlcR0ib0lcNDXSMnU3fcCDgKEXi3V-ogHvWv9duPnZq1sQw8bnlMGo1wp2xTUup9kFsyWxf2qibvNePahKOj1H4ry6zeWZpv6clNn9X9xwPnxLIkcXWDf3tFb9o5';
                
    $fields = array (
        'registration_ids' => array (
                $device_id
        ),
        'data' => array (
                "current" => $c,
				"next" => $n,
				"service" => $service
        )
    );

    //header includes Content type and api key
    $headers = array(
        'Content-Type:application/json',
        'Authorization:key='.$api_key
    );
                
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
    return $result;
}

function base64url_encode($str) {
    return rtrim(strtr(base64_encode($str), '+/', '-_'), '=');
}
function is_jwt_valid($jwt, $secret = 'secretk') {
	// split the jwt
	$tokenParts = explode('.', $jwt);
	$header = base64_decode($tokenParts[0]);
	$payload = base64_decode($tokenParts[1]);
	$signature_provided = $tokenParts[2];
	// check the expiration time - note this will cause an error if there is no 'exp' claim in the jwt
	$expiration = json_decode($payload)->exp;
	$is_token_expired = ($expiration - time()) < 0;
    $headers = array('alg'=>'HS256','typ'=>'JWT');
    $header=json_encode($headers);
    //$payload = array('uid'=>json_decode($payload)->uid,'phone'=> json_decode($payload)->phone,  'role'=>json_decode($payload)->role, 'exp'=>json_decode($payload)->exp);
	// build a signature based on the header and payload using the secret
	$base64_url_header = base64url_encode($header);
	$base64_url_payload = base64url_encode($payload);
    $signature = hash_hmac('SHA256', $base64_url_header . "." . $base64_url_payload, $secret, true);
	$base64_url_signature = base64url_encode($signature);
	// verify it matches the signature provided in the jwt
	$is_signature_valid = ($base64_url_signature === $signature_provided);
	if ($is_token_expired || !$is_signature_valid) {
		return FALSE;
	} else {
		return TRUE;
	}
}
?>