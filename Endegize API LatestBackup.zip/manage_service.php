<?php
//session_start();
$res=array();
$token = null;
  $headers = apache_request_headers();
  if(isset($headers['Authorization'])){
    if(isset($headers['Authorization'])){
      $token = $headers['Authorization'];
      if($token==null){
        $res['error']=1;
		$res['mesg']='Token is null, please login and try again';
		echo json_encode($res);
	    return;
    }
    $vd=is_jwt_valid($token, $secret = 'secretk');
    if($vd==false){
        $res['error']=1;
		$res['mesg']='Invalid credential, please login and try again';
		echo json_encode($res);
	    return;
    }
  }
}
else{
      $res['error']=1;
		$res['mesg']='Please login, and try again';
		echo json_encode($res);
	    return;
}
include("dbconnection.php");
include("service.php");
include("queue.php");

if ($_SERVER['REQUEST_METHOD'] == "POST"){
	
	$data=json_decode(file_get_contents('php://input'), true);
	if(isset($data['coordinator'] )){
		$uid=$data['coordinator'];
			$ar=array();
			$svcs=array();
			$svcstate=array();
		$ret=mysqli_query($con,"SELECT * FROM service WHERE coordinator='$uid'");
		while($num=mysqli_fetch_array($ret)){
			$svcs[]= $num;
			$svc=new service();
			$state=$svc->get_service_session($num['sid']);
			//$svcstate[]= $state;
		}
		
		$ar['agentstatus']=$svcs;
		//$ar['agentstatuss']=$svcstate;
		echo json_encode($ar);
	}
	if(isset($data['gcid']))
	{
		$cid=$data['gcid'];
		$ret=mysqli_query($con,"select distinct(sid), name,coordinator from service where cid='$cid'");
		$num=mysqli_fetch_array($ret);
		$svcs=array();
		$ar=array();
		while($num=mysqli_fetch_assoc($ret)){
			$svc=new service();
			$current=$svc->get_current_queue_byservice($num['sid'])['current'];
			$svc=new service();
			$state=$svc->get_service_session($num['sid']);
			$svc=new service();
			$total=$svc->get_total_queue_byservice($num['sid'])['total'];
			$tmp=array('name'=>$num['name'],'sid'=>$num['sid'],'coordinator'=>$num['coordinator'],'total'=>$total,'current'=>$current,'status'=>$state);
			$svcs[]=$tmp;		
		}
		$ar['compstatus']=$svcs;

		echo json_encode($ar);
	}
	if(isset($data['startqsession']) && isset($data['sid']) )
	{
			$svc=new service();
			if($svc->start_service_session($data['sid'])==1){
			    echo json_encode("Started successfully and received by users.");
			}
			else{
			    echo json_encode("Seems started already.");
			}
	}
	 if(isset($data['stopqsession']) && isset($data['sid']) ){
		$svc=new service();
		if($svc->off_service_session($data['sid'])==1){
			    echo json_encode("Stopped successfully and received by users.");
			}
			else{
			    echo json_encode("Seems stopped alread.");
			}
	}
	
}


if(isset($_GET['DforSync'])){
    $svc=new queue();
	$r=$svc->getListofQueuesbyService($_GET['sid'],10);
	$resp['qdata_sync']=$r;
	echo json_encode($resp);
}
if(isset($_GET['coordinator'] )){
		$uid=$_GET['coordinator'];
			$ar=array();
			$svcs=array();
			$svcstate=array();
		$ret=mysqli_query($con,"SELECT * FROM service WHERE coordinator='$uid'");
		while($num=mysqli_fetch_array($ret)){
			$svc=new service();
			$qw=new queue();
			$state=$svc->get_service_session($num['sid']);
			$num['state']=$state;
		    $num['nextrange']=$qw->getNextRangeQueueNumber($num['sid']);
			$svc=new service();
		    $num['total']=$svc->get_total_queue_byservice($num['sid'])['total'];
			$svcs[]= $num;
			
			//$svcstate[]= $state;
		}
		
		$ar['agentstatus']=$svcs;
		//$ar['agentstatuss']=$svcstate;
		echo json_encode($ar);
	}

if(isset($_GET['gcid']))
	{
		$cid=$_GET['gcid'];
		$ret=mysqli_query($con,"select distinct(sid), name,coordinator,detail from service where cid='$cid'");
		$num=mysqli_fetch_array($ret);
		$svcs=array();
		$ar=array();
		while($num=mysqli_fetch_assoc($ret)){
			$svc=new service();
			$current=$svc->get_current_queue_byservice($num['sid'])['current'];
			$svc=new service();
			$state=$svc->get_service_session($num['sid']);
			$svc=new service();
			$total=$svc->get_total_queue_byservice($num['sid'])['total'];
			$tmp=array('name'=>$num['name'],'sid'=>$num['sid'],'coordinator'=>$num['coordinator'],'total'=>$total,'current'=>$current,'status'=>$state, 'detail'=>$num['detail']);
			$svcs[]=$tmp;		
		}
		$ar['servstatus']=$svcs;

		echo json_encode($ar); 
	}
	
	
if(isset($_GET['getlistofissuers']) && isset($_GET['sid']) )
{
	$svc=new service();
	$r=$svc->get_queue_detail_byservice($_GET['sid']);
	$resp['issuersliststatus']=$r;
	echo json_encode($resp);
}

if(isset($_GET['startqsession']) && isset($_GET['sid']) )
{
		$svc=new service();
		$svc->start_service_session($_GET['sid']);
}
else if(isset($_GET['stopqsession']) && isset($_GET['sid']) )
{
		$svc=new service();
		$svc->off_service_session($_GET['sid']);
}
if(isset($_POST['cid']) && isset($_POST['name']) && isset($_POST['coordinator']) )
{
	if($_POST['name']!=null && $_POST['cid']!=null){
		echo $_POST['name'];
		$sid=md5($_POST['name'].' '.$_POST['cid']);
		echo $sid;
		$ret=mysqli_query($con,"insert into 
		service (sid,name,cid,coordinator) values ('".$sid."','".$_POST['name']."','".$_POST['cid']."','".$_POST['coordinator']."')");
		//$ret->bind_params("sssiis",$uid,$_POST['fname'],$_POST['lname'],$_POST['pin'],$_POST['phone'],$uid);
		//$ex=$ret->execute();
		echo "insert into service (sid,name,cid,coordinator) values ('".$sid."','".$_POST['name']."','".$_POST['coordinator']."','".$_POST['cid']."')";
	}
}


else if(isset($_POST['gsid']) )
{
	$uid=$_POST['gsid'];
	$ret=mysqli_query($con,"SELECT * FROM service WHERE sid='$uid'");
	$num=mysqli_fetch_array($ret);
	if($num>0)
	{
		echo $num['name'];
	}
}

/*************************/
if(isset($_GET['on_service']) && isset($_GET['sid'])){
	$qw = new queue();
	$numbs=array();
	$numbs['on_service']=$qw->getOn_ServiceIssuers($_GET['sid']);
	echo json_encode($numbs);
}

if(isset($_GET['blockuser'])){
	$qw = new queue();
	echo json_encode($qw->block_from_queue($_GET['blockuser']));
}
if(isset($_GET['leaveQ'])){
	$qw = new queue();
	$arr=array();
	$arr['leaveq']=$qw->delete_queue($_GET['leaveQ']);
	echo json_encode($arr);
}

if(isset($_GET['skipIssuer'])){
	$qw = new queue();
	echo json_encode($qw->completeQueue('auto_completed','Not available on time',$_GET['skipIssuer']));
}

function base64url_encode($str) {
    return rtrim(strtr(base64_encode($str), '+/', '-_'), '=');
}
function is_jwt_valid($jwt, $secret = 'secretk') {
	// split the jwt
	$tokenParts = explode('.', $jwt);
	$header = base64_decode($tokenParts[0]);
	$payload = base64_decode($tokenParts[1]);
	$signature_provided = $tokenParts[2];
	// check the expiration time - note this will cause an error if there is no 'exp' claim in the jwt
	$expiration = json_decode($payload)->exp;
	$is_token_expired = ($expiration - time()) < 0;
    $headers = array('alg'=>'HS256','typ'=>'JWT');
    $header=json_encode($headers);
    //$payload = array('uid'=>json_decode($payload)->uid,'phone'=> json_decode($payload)->phone,  'role'=>json_decode($payload)->role, 'exp'=>json_decode($payload)->exp);
	// build a signature based on the header and payload using the secret
	$base64_url_header = base64url_encode($header);
	$base64_url_payload = base64url_encode($payload);
    $signature = hash_hmac('SHA256', $base64_url_header . "." . $base64_url_payload, $secret, true);
	$base64_url_signature = base64url_encode($signature);
	// verify it matches the signature provided in the jwt
	$is_signature_valid = ($base64_url_signature === $signature_provided);
	if ($is_token_expired || !$is_signature_valid) {
		return FALSE;
	} else {
		return TRUE;
	}
}
/* 
if(isset($_GET['get_remaining']) && isset($_GET['sid']) && isset($_GET['uid'])){
	$svc=new service();
	var_dump($svc->get_remaining($_GET['sid'],$_GET['uid']));
} */
?>