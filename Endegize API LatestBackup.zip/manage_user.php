<?php
//session_start();

include("dbconnection.php");
include("service.php"); 
header('Content-type: application/json');
if ($_SERVER['REQUEST_METHOD'] == "POST"){
	
	$data=json_decode(file_get_contents('php://input'), true);
	$res=array();
	if($data['loginphone']!=null && $data['loginpin']!=null ){
		$phone=$data['loginphone'];
		$pin=$data['loginpin'];
		$ret=mysqli_query($con,"SELECT * FROM users WHERE phone='$phone' and pin='$pin'");
		$num=mysqli_fetch_array($ret);
		if($num>0)
		{
			
			$res['stats']=$num;
			echo json_encode($res);
		}
		else{
			$res['loginstatus']='0';
			echo json_encode($res);
		}
	}
}
if(isset($_POST['uid']) && isset($_POST['coordinator_entities'])){
	$uid=$_POST['uid'];
	$svs=array();
	$ret=mysqli_query($con,"select c.cid,sid,s.name as servicename,c.name as companyname from company c, service s where s.coordinator='$uid' and c.cid=s.cid and coordinator in (select uid from users where role='coordinator')");

	while($num=mysqli_fetch_array($ret)){
		$svc=new service();
		$state=$svc->get_service_session($num['sid']);
		$svc=new service();
		$total=$svc->get_total_queue_byservice($num['sid'])['total'];
		$temp=array();
		array_push($temp,$num['sid'],$num['cid'],$_POST['uid'],$num['servicename'],$num['companyname'],$total,$state);
	$svs[]=$temp;		
	}
	echo json_encode($svs);
}
if(isset($_GET['loginphone']) && isset($_GET['loginpin']) )
{
	$res=array();
	if($_GET['loginphone']!=NULL && $_GET['loginpin']!=NULL){
	    $header='{  "alg": "HS256",  "typ": "JWT"}';
		$phone=$_GET['loginphone'];
		$pin=$_GET['loginpin'];
		$ret=mysqli_query($con,"SELECT * FROM users WHERE phone='$phone' and pin='$pin'");
		$num=mysqli_fetch_array($ret);
		if($num>0)
		{
		    $res['error']=0;
		    
            $headers = array('alg'=>'HS256','typ'=>'JWT');
            $payload = array('uid'=>$num['uid'],'phone'=> $num['phone'],  'role'=> $num['role'], 'exp'=>(time() + 10000));
			$jwt = generate_jwt($headers, $payload);
			header("Authorization: $jwt\r\n");
			$num['ltoken']=$jwt; 
			$res['loginstatus']=$num;
		}
		else{
		    $res['error']=1;
			$res['loginstatus']='0';
		}
	}else{
		    $res['error']=1;
		    $res['mesg']='Please enter credentials and try again';
	    
	}
		echo json_encode($res);
}
 if(isset($_GET['phone']) && isset($_GET['fname']) && isset($_GET['lname']))
{
		$res=array();
	if($_GET['phone']!=null){
		$uid=md5($_GET['phone'].' '.$_GET['fname'].' '.$_GET['lname']);
		$fn=$_GET['fname'];
		$ln=$_GET['lname'];
		$ph=$_GET['phone'];
		$pin=$_GET['pin'];
		$ret=mysqli_query($con,"insert into users (uid,fname,lname,pin,phone,token) values ('".$uid."','".$fn."','".$ln."','".$pin."','".$ph."','".$uid."')");
		//echo "insert into users (uid,fname,lname,pin,phone,token) values ('".$uid."','".$fn."','".$ln."','".$pin."','".$ph."','".$uid."')";
		//$ret->execute();
		if($ret){
		    $res['error']=0;
		    $res['mesg']='Registered successfully';
		}else{
		    $res['error']=1;
		    $res['mesg']='Unable to register.';
		}
	}else{
		    $res['error']=1;
		    $res['mesg']='Please fill all required fields and try again.';
	    
	}
		echo json_encode($res);
}


if(isset($_GET['upin']) && isset($_GET['npin1']) && isset($_GET['npin2']) &&  isset($_GET['uid']))
{
		$res=array();
    if($_GET['npin1'] != $_GET['npin2']){
		    $res['error']=1;
		    $res['mesg']='Different pins entered';
    }
    else if($_GET['uid']!=null){
		$ret=mysqli_query($con,"update users set pin='".$_GET['npin2']."' where uid='".$_GET['uid']."' && pin='".$_GET['upin']."'");
		var_dump($ret);
		if($ret){
		    $res['error']=0;
		    $res['mesg']='Updated successfully';
		}else{
		    $res['error']=1;
		    $res['mesg']='Not updated, please try again.';
		}
	}else{
		    $res['error']=1;
		    $res['mesg']='Unknown error, please enter valid pins and try again';
	}
		echo json_encode($res);
}

if(isset($_GET['uphone']) && isset($_GET['ufname']) && isset($_GET['ulname']) && isset($_GET['uid']))
{
		$res=array();
	if($_GET['uphone']!=null){ 
		$ret=mysqli_query($con,"update users set fname='".$_GET['ufname']."',lname='".$_GET['ulname']."',phone='".$_GET['uphone']."' where uid='".$_GET['uid']."'");
		//$ex=$ret->execute();
		if($ret){
		    $res['error']=0;
		    $res['mesg']='Updated successfully';
		}else{
		    $res['error']=1;
		    $res['mesg']='Not updated, please try again.';
		}
	}else{
		    $res['error']=1;
		    $res['mesg']='Phone not found, please try again';
	}
		echo json_encode($res);
}

if( isset($_GET['getuserbyphone']))
{
	$phone=$_GET['getuserbyphone'];
	$ret=mysqli_query($con,"SELECT * FROM users WHERE phone like '$phone%'");
	$num=mysqli_fetch_array($ret);
	echo json_encode($num);
}

function generate_jwt($headers, $payload, $secret = 'secretk') {
    $headers_encoded = base64url_encode(json_encode($headers));
    $payload_encoded = base64url_encode(json_encode($payload));
    $signature = hash_hmac('SHA256', "$headers_encoded.$payload_encoded", $secret, true);
    $signature_encoded = base64url_encode($signature);
    $jwt = "$headers_encoded.$payload_encoded.$signature_encoded";
    return $jwt;
}

function base64url_encode($str) {
    return rtrim(strtr(base64_encode($str), '+/', '-_'), '=');
}

function is_jwt_valid($jwt, $secret = 'secretk') {
	// split the jwt
	$tokenParts = explode('.', $jwt);
	$header = base64_decode($tokenParts[0]);
	$payload = base64_decode($tokenParts[1]);
	$signature_provided = $tokenParts[2];

	// check the expiration time - note this will cause an error if there is no 'exp' claim in the jwt
	$expiration = json_decode($payload)->exp;
	$is_token_expired = ($expiration - time()) < 0;

	// build a signature based on the header and payload using the secret
	$base64_url_header = base64url_encode($header);
	$base64_url_payload = base64url_encode($payload);
	$signature = hash_hmac('SHA256', $base64_url_header . "." . $base64_url_payload, $secret, true);
	$base64_url_signature = base64url_encode($signature);

	// verify it matches the signature provided in the jwt
	$is_signature_valid = ($base64_url_signature === $signature_provided);
	
	if ($is_token_expired || !$is_signature_valid) {
		return FALSE;
	} else {
		return TRUE;
	}
}

/* 
else if(isset($_POST['uid']) )
{
	$uid=$_POST['uid'];
	$ret=mysqli_query($con,"SELECT * FROM users WHERE uid='$uid'");
	$num=mysqli_fetch_array($ret);
	if($num>0)
	{
		echo $num['phone'];
	}
} */
?>