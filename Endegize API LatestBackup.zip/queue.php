<?php
$q=new queue();
$q->f();
class queue {
	var $conn=NULL;
	var $servername = "localhost:3306";
	var $username = "emeraldl_emeraldl";
	var $password = "Liner2@root";
	var $dbname = "emeraldl_liner2";
	var $newn=0;
  function __construct() {
      
	$this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
	if ($this->conn->connect_error) {
	  die("Connection failed: " . $this->conn->connect_error);
	}
    $stmt=$this->conn->prepare("SET time_zone ='-06:30'");
	$stmt->execute();
	
  } 
  function f(){
      $det='መሟላት ያለባቸው  ነገሮች ፡<br/>
የታደሰ የቀበሌ መታወቂያ<br/>
ሁለት ጉርድ ፎቶ፡<br/>
ሶስት ምስክር እያንዳንዳቸው የታደሰ የቀበሌ መታወቂያ፡<br/>
ለአገግሎቱ የሚያስፈልገው ሰዓት 26 ደቂቃ ፡<br/>
ጉዳዮትን እንድንከታተልልዎት ከፈለጉ ለበለጠ በ <a href=\"tel:0915998916\">0915998916</a> ይደውሉ ';	
$stmt=$this->conn->prepare("update service set detail=? ");
	$stmt->bind_param("s",  $det);
	$stmt->execute();
  }
  function startConnection(){
	$this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
	if ($this->conn->connect_error) {
	  die("Connection failed: " . $this->conn->connect_error);
	}	  
  }
  function set_queue( $sid,$token,$channel,$ftoken){
	$tod=date("Y-m-d");
	$qid=md5($sid.' '. $tod.' '.$token);
	if($this->get_service_session($sid)==0){
		return "Sorry, queue has not been started. \nPlease try later.";
		exit();
	}
	$mesg=array();
	$this->getLastQueueNumber($sid);
	$newnm= (int)$this->newn;
	$newnm++;
	$stmt=$this->conn->prepare("INSERT INTO queue (qid, sid,number,token,channel,ftoken) VALUES (?,?,?,?,?,?)");
	$stmt->bind_param("ssssss",$qid,$sid, $newnm,$token, $channel,$ftoken);
	if($stmt->execute()){
	    $mesg['error']=0;
	    $mesg['mesg']=  "New records created successfully. You are ".$newnm;
	}
	 else{	    
	    $mesg['error']=1;
	    $mesg['mesg']=  "Already issued. Please check on issued list";
	 }	   
	$stmt->close();
      return $mesg;
  }
  
function get_service_session( $sid){
	$tod=date("Y-m-d");//echo "select distinct(qsid) as qsid,timeon,timeoff,state from qsession where sid='$sid' and issue_time like '".$tod."%'  ";
	$stmt=$this->conn->prepare("select distinct(qsid) as qsid,timeon,timeoff,state from qsession where sid=? and timeon like '".$tod."%'  ");
	$stmt->bind_param("s",  $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number=0;
	$stmt->close();
	//$this->conn->close();
	if ($row = $result->fetch_assoc()) {
		return $row['timeon'];
	}else{
		return "0";
	}
}
  function getLastQueueNumber($sid){
	  //$this->startConnection();
	  $tod=date("Y-m-d");
	  $stmt=$this->conn->prepare("select max(number) as number from queue where sid=? and issue_time like '".$tod."%'  and state!='checkedin' and status!='blocked' ");
	  $stmt->bind_param("s",  $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number=0;
	if ($row = $result->fetch_assoc()) {
		$this->newn=(int)$row['number'];
	}
	$stmt->close();
	//$this->conn->close();
	return $number;
  }
  function getLastQueueNumberCopy($sid){
	  //$this->startConnection();
	  $tod=date("Y-m-d");
	  $stmt=$this->conn->prepare("select max(number) as number from queue where sid=? and issue_time like '".$tod."%'  and state!='checkedin' and status!='blocked' ");
	  $stmt->bind_param("s",  $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number=0;
	if ($row = $result->fetch_assoc()) {
		$number=(int)$row['number'];
	}
	$stmt->close();
	//$this->conn->close();
	return $number;
  }
  function getNextQueueNumber($sid){
	  //$this->startConnection();
	  $tod=date("Y-m-d");
	  $stmt=$this->conn->prepare("select min(number) as number from queue where sid=? and issue_time like '".$tod."%' and state!='checkedin' and status!='blocked' ");
	  $stmt->bind_param("s",  $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number=0;
	if ($row = $result->fetch_assoc()) {
		$number=$this->newn=(int)$row['number'];
	}
	$stmt->close();
	//$this->conn->close();
	return $number;
  }function getUserbyQid($qid){
	  //$this->startConnection();
	  $stmt=$this->conn->prepare("select distinct(token)  from queue where qid=? ");
	  $stmt->bind_param("s",  $qid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number='';
	if ($row = $result->fetch_assoc()) {
		$number=$row['token'];
	}
	$stmt->close();
	//$this->conn->close();
	return $number;
  }
  
function getNextRangeQueueNumber($sid){
	  //$this->startConnection();
	  $tod=date("Y-m-d");
	  $stmt=$this->conn->prepare("select distinct(qid) as qid,number,token,state from queue where sid=? and issue_time like '".$tod."%' and state!='checkedin' and status!='blocked' and state='next' order by number");
	  $stmt->bind_param("s",  $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number=array();
	while ($row = $result->fetch_assoc()) {
		$number[]=$row;
	}
	$stmt->close();
	//$this->conn->close(); 
	if(count($number)==0)
	    $number[]=$this->getNextQueueNumber($sid);
	return $number;
}

  function getListofQueuesbyService($sid,$limit){
      
	 // $tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select * from queue where sid=? and  state!='checked_in' and status!='blocked' limit ?");
	$stmt->bind_param("si", $sid,$limit);
	$stmt->execute();
	$num=array();
	$result = $stmt->get_result();
	while ($row = $result->fetch_assoc()) {
		$num[]=$row;
	}
	$stmt->close();
	return ($num);
  
  }
  function get_queue_detail_byservice($sid){
	  echo $sid;
	$stmt = $this->conn->prepare("select * from queue where sid=?");
	$stmt->bind_param("s", $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	while ($row = $result->fetch_assoc()) {
		echo $row['token'];
	}
	$stmt->close();
	//$this->conn->close();
	return json_encode($result);
  }
  function get_total_queue_byservice($sid){
	  
	$stmt = $this->conn->prepare("select count(qid) as total from queue where sid=? and state!='checked_in' and status!='blocked'");
	$stmt->bind_param("s", $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$stmt->close();
	//$this->conn->close();
	return json_encode($result);
  }
  function get_listof_issued_queue ($uid){
	$tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select s.name as servicename,c.name as companyname,s.cid as cid,s.sid as sid, qid,issue_time,token,state, channel,status,number from service s,company c,queue q where (q.sid=s.sid and (q.state='waiting' or q.state='next') and token=? and issue_time like '$tod%' ) and (s.cid=c.cid);");
	$stmt->bind_param("s", $uid);
	$stmt->execute();
	$qdetail=array();
	$result = $stmt->get_result();
	while($res = $result->fetch_assoc()){
		$temp=array();
		$temp=$this->get_remaining($res['sid'],$uid);
		array_push($res,$temp);
		$temp['next']=$this->getNextRangeQueueNumber($res['sid']);
		array_push($res,$temp);
		$qdetail[]=$res;
	}
	$stmt->close();
	
	//$this->conn->close();
	//return json_encode($result);
	return $qdetail;
  }
  function get_queue_detail($uid,$sid){
	  $tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select * from queue where sid =? and token=? and issue_time like '$tod%';");
	$stmt->bind_param("ss", $sid,$uid);
	$stmt->execute();
	$result = $stmt->get_result();
	$stmt->close();
	//$this->conn->close();
	return ($result);
  }
  function callForNext($range, $sid){
	  $tod=date("Y-m-d");
	  if($range>=1){
		  $stmt=$this->conn->prepare("update queue set state='next' where sid=? and issue_time like '$tod%' and state='waiting' and (status!='blocked' and state!='next' and state!='checkedin') and number in (select * from (select  number from queue where sid=? and issue_time like '$tod%' and (status!='blocked' and state!='next' and state!='checkedin') order by issue_time asc, number asc limit ?) as number);");
		  $stmt->bind_param("ssi",$sid,$sid,$range);
		  $stmt->execute();
		  $stmt->close();
		  return "Notified successfully";
	  }
	  else{
		  return "Invalid range of issuers.";
	  }
  }
  
  
  function call_queue($qid,$sid,$uid,$coordinator,$comment,$status){
	$tod=date("Y-m-d");
	$response=array();
	$this->updateOnservice($sid);
	if($qid=="")
	    $qid=$this->get_queueID($sid,$uid);
	else{
	    $uid=$this->getUserbyQid($qid);
	}
	$nextnm=$this->getNextQueueNumber($sid);
	$gin=$this->get_issuer_number($sid,$uid);
	
	$mesg="";
	if(count($gin)>0){
		$i_number=$gin['number'];		
		$i_state=$gin['state'];
		//echo $i_state.'  '.$i_number;
		if($i_state=='waiting' && $i_number!=$nextnm){
			$rem=$this->get_remaining($sid,$uid);
			$response['error']=1;
			$response['mesg']="You are not within the selectee! ".$rem['offset']." remaining";
		}else if($i_state=='next' || ($i_state=='waiting' && $i_number==$nextnm)){
			$stmt = $this->conn->prepare("update queue set state='checkedin' where ((state='waiting' and number=$nextnm) or state='next') and state!='checkedin' and status!='blocked' and qid=? and issue_time like '$tod%' ;");
			$stmt->bind_param("s", $qid);
			$stmt->execute();
			$stmt->close();
			//insert into served
			$cd=date("Y-m-d H-i-s");
			$osid=md5($qid.' '. $coordinator);
			$stmt = $this->conn->prepare("insert into on_service(osid,coordinator,qid) values (?,?,?)");
			$stmt->bind_param("sss", $osid,$coordinator,$qid);
			$rr=$stmt->execute();
			$stmt->close();
			$response['error']=0;
			$response['next']='Next- '.$this->getNextQueueNumber($sid);
			$response['current']='Current- '.$i_number;
			$response['mesg']="Service has been delivered successfully.";
		}
	}
	else{
			$response['error']=2;
			$response['mesg']="User haven't issued to this service!";
	}
	return $response;
  } 
  
 function get_queueID($sid,$uid){
	  $tod=date("Y-m-d");
	  $stmt=$this->conn->prepare("select distinct(qid) as qid from queue where sid=? and token=? and issue_time like '".$tod."%'");
	  $stmt->bind_param("ss",$sid,$uid);
	  $stmt->execute();
	  $result = $stmt->get_result();
	  if($row=$result->fetch_assoc()){
		return $row['qid'];	
	  }
	  $stmt->close();
}

 
 function get_queueIDbylast4qid($qd,$sid){
	  $tod=date("Y-m-d");
	  $qd='%'.$qd;
	  $stmt=$this->conn->prepare("select distinct(qid) as qid from queue where qid like ? and sid=? and issue_time like '".$tod."%'");
	  $stmt->bind_param("ss",$qd,$sid);
	  $stmt->execute();
	  $result = $stmt->get_result();
	  if($row=$result->fetch_assoc()){
		return $row['qid'];	
	  }
	  $stmt->close();
}
function getSidbyQid($qid){
	$tod=date("Y-m-d");
	 $stmt=$this->conn->prepare("select distinct(sid) as sid from queue where qid=?  and issue_time like '".$tod."%'");
	  $stmt->bind_param("s",$qid);
	  $stmt->execute();
	  $result = $stmt->get_result();
	  if($row=$result->fetch_assoc()){
		return $row['sid'];	
	  }
	  $stmt->close();
}
function remindNextwaiters($sid){
     $tod=date("Y-m-d");
	$stmt=$this->conn->prepare("select DISTINCT(qid),s.name as servicename, ftoken,state from queue q, service s where q.sid=s.sid and issue_time like '$tod%' and state!='checkedin' and status!='blocked' and (number>= (select min(number) from queue where issue_time like '$tod%' and state!='checkedin' and status!='blocked' and q.sid=?) ) and q.sid=? and ftoken!='' order by issue_time asc,number asc ");
		  $stmt->bind_param("ss",$sid,$sid);
		  $stmt->execute();
		  $result = $stmt->get_result();
		  $numbs=array();
		  while($row=$result->fetch_assoc()){
			$numbs[]= $row;	
		  }
		  $stmt->close();
		  return $numbs;
}
  function shift_queue($qid,$uid,$sid,$number){
	$tod=date("Y-m-d");
	if($qid!=""){
		//if($number==null){
			$sid=$this->getSidbyQid($qid);
			$number=($this->getLastQueueNumberCopy($sid)+1);
		//}
		$gg=$this->get_issuer_number($qid);
		$i_number=$gg['number'];
		$i_status=$gg['status'];
		if($number>$i_number && $i_status!='selfshifted'){
			$stmt = $this->conn->prepare("update queue set number=?,issue_time=CURRENT_TIMESTAMP, status='selfshifted',state='waiting' where qid=? and state!='checkedin'  and status!='blocked' and issue_time like '$tod%' and status!='selfshifted'");
			$stmt->bind_param("s", $qid);
			$stmt->execute();
			return "Shifted successfully to number ".$number;
			$stmt->close();
		}
		else if($number<=$i_number){
			return "Shifting to lower number is not allowed";
		}
		else if($i_status=='selfshifted'){
			return "More than one chance is not permitted.";
		}
	}
	else{
		$number=($this->getLastQueueNumberCopy($sid)+1);
		$gin=$this->get_issuer_number($sid,$uid);
		if(count($gin)>0){
			$i_number=$gin['number'];
			$i_status=$gin['status'];
			if($number>$i_number && $i_status!='selfshifted'){
				$stmt = $this->conn->prepare("update queue set number=$number,issue_time=CURRENT_TIMESTAMP, status='selfshifted' ,state='waiting' where sid=? and token=? and state!='checkedin'  and status!='blocked' and issue_time like '$tod%' and status!='selfshifted' ");
				$stmt->bind_param("ss", $sid,$uid);
				if($stmt->execute())
				    return "Shifted successfully to number ".$number;
				else
				    return "Shifting failed.";
				$stmt->close();
		}
		if($number<=$i_number){
			return "Shifting to lower number is not allowed";
		}
		if($i_status=='selfshifted'){
			return "More than one chance is not permitted.";
		}
		}else{
			return "Please issue to this service.";
		}
	}
  }
  
function get_issuer_number_byQid($qid){
	$tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select distinct(number) as number,state,status,qid from queue where qid=? and state!='checkedin'  and status!='blocked' and issue_time like '$tod%'  ");
	$stmt->bind_param("s", $qid);
	$stmt->execute();
	$num=array();
	$result = $stmt->get_result();
	if($row = $result->fetch_assoc()){
		$num= $row;
	}
	$stmt->close();
	return $num;
}
function get_remaining($sid,$uid){
	$tod=date("Y-m-d");
	$number=$this->get_issuer_number($sid,$uid)['number'];
	$stmt = $this->conn->prepare("select count(qid) as offset from queue where issue_time like '$tod%' and state!='checkedin' and status!='blocked' and (number>= (select min(number) from queue where issue_time like '$tod%' and state!='checkedin' and status!='blocked' and sid=?) and number<$number) and sid=? ;");
	$stmt->bind_param("ss", $sid,$sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_assoc();
	$stmt->close();
	return ($row);
  
}

function get_issuer_number($sid,$uid){
	$tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select distinct(number),state,status,qid from queue where sid=? and state!='checkedin'  and status!='blocked' and token=? and issue_time like '$tod%'  ");
	$stmt->bind_param("ss", $sid,$uid);
	$stmt->execute();
	$result = $stmt->get_result();
	if($row = $result->fetch_assoc()){
		return $row;
	}
	$stmt->close();
  
}
  
/***********************************/
  function delete_queue($qid){
      $r="";
	  $stmt = $this->conn->prepare("delete from queue where qid=? ");
	$stmt->bind_param("s", $qid);
		if($stmt->execute())
			$r= "Left successfully ";
			else{
			    $r= "Failed to leave";
			}
			$stmt->close();
			return $r;
  }
  function block_from_queue(){
	$stmt = $this->conn->prepare("update queue set status='blocked' where qid=? ");
	$stmt->bind_param("s", $qid);
	$stmt->execute();
	echo "Blocked successfully ";
	$stmt->close();
  }  
  function getOn_ServiceIssuers($sid){
	  $tod=date("Y-m-d");
		  $stmt=$this->conn->prepare("select q.qid, sid,number,called_time,o.coordinator from on_service o, queue q where q.qid=o.qid and o.status='on_service' and sid=?  and called_time like '$tod%' order by called_time asc,number asc; ");
		  $stmt->bind_param("s",$sid);
		  $stmt->execute();
		  $numbs=array();
		  while($row=$result->fetch_assoc()){
			$numbs[]= $row;	
		  }
		  $stmt->close();
		  return $numbs;
	  
  }
  function updateOnservice($sid){
	$tod=date("Y-m-d");
	$stmt=$this->conn->prepare("update on_service set status='completed', completed_time=CURRENT_TIMESTAMP where status='on_service' and called_time like '$tod%' and qid in (select distinct(qid) from queue where state='checkedin' and issue_time like '$tod%' and sid = ?)");
	$stmt->bind_param("s",$sid);
	$stmt->execute();
	
  }
  function completeQueue($status,$comment,$qid){
	$tod=date("Y-m-d ");
	//$this->startConnection();
	$stmt = $this->conn->prepare("update on_service set status=?, comment=?, completed_time=CURRENT_TIMESTAMP where qid=? and called_time like '$tod%'");
	$stmt->bind_param("sss", $status,$comment,$qid);
	$stmt->execute();
	$stmt->close();
	echo "Issuer skipped successfully. Next waiter will be called.";
  }
  
}
?>