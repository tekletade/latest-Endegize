<?php
$db = mysqli_connect('localhost:3306','emeraldl_liner','Liner@12345678','emeraldl_liner');
if(!$db)
{
	echo "Database connection failed";
}
$phone = $_POST['phone'];
$password = $_POST['password'];

$sql = "SELECT phone FROM user WHERE phone = '".$phone."'";
$result = mysqli_query($db,$sql);
$count = mysqli_num_rows($result);
if($count == 1){
	echo json_encode("Error");
}else{
	$insert = "INSERT INTO user(phone,password) VALUES ('".$phone."','".$password."')";
		$query = mysqli_query($db,$insert);
		if($query){
			echo json_encode("Success");
		}
}
?>