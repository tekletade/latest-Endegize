<?php

define('TIMEZONE', 'Africa/Addis_Ababa');
date_default_timezone_set(TIMEZONE);
$now = new DateTime();
$mins = $now->getOffset() / 60;
$sgn = ($mins < 0 ? -1 : 1);
$mins = abs($mins);
$hrs = floor($mins / 60);
$mins -= $hrs * 60;
$offset = sprintf('%+d:%02d', $hrs*$sgn, $mins);
//Your DB Connection - sample

$db = new PDO('mysql:host=localhost:3306;dbname=emeraldl_liner2', 'emeraldl_emeraldl', 'Liner2@root');
$db->exec("SET time_zone='$offset';");
class search {
    
	var $conn=NULL;
	var $servername = "localhost:3306";
	var $username = "emeraldl_emeraldl";
	var $password = "Liner2@root";
	var $dbname = "emeraldl_liner2";
	var $newn=0;
  function __construct() {
     
  
	$this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
	if ($this->conn->connect_error) {
	  die("Connection failed: " . $this->conn->connect_error); 
	}
  }
  function startConnection(){ 
	$this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
	if ($this->conn->connect_error) {
	  die("Connection failed: " . $this->conn->connect_error);
	}	  
  }
  function searchQ($text){
      //This is test for and 0-n-1 ,0-n-2 1:n-1
      $down=0;
     $arr = explode(" ", $text);
     $arr =array_unique($arr);
     $number=array();
     if(count($arr)>0){
         
      $up=0;
      $str="";
      for($i=0;$i<count($arr);$i++){
          $down++;
          $c=$down;
          for($up=0;$up<$down;$up++){
              $e=(count($arr)-$c);
              for($r=$up;$r<=$e;$r++){
                 $str.=$arr[$r].' ';
              }
              $c--;
              //echo 'searching '.trim($str).'<hr/>';
              $res=$this->query(trim($str));
              while($row=$res->fetch_assoc()){
                 $number[]=$row;
              }
          $str=""; 
          }
      }
     	return $number;
     }else{
         return "0";
     }
         
     }

function query($str){
    $prm='%'.$str.'%';  
	  $stmt=$this->conn->prepare("select distinct(sid) as sid,c.name as companyname,s.name as sname,s.cid as cid from service s, company c where c.cid=s.cid and (c.name like ? or s.name like ?) ");
	  $stmt->bind_param("ss",  $prm,$prm); 
	$stmt->execute();
	$result = $stmt->get_result();
	$r= $result;
	$stmt->close(); 
	return $r;
}
}
if(isset($_GET['searchq'])){
    $sqr=array(); 
    if($_GET['searchq']!=null){
        $sq=new search();
        $sqr['s_result']=$sq->searchQ($_GET['searchq']);
        echo json_encode($sqr);
    }else{
         $sqr['s_result']="No query to search, please enter company or service name.";
        echo json_encode($sqr);
     }
}
