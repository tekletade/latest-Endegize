<?php
date_default_timezone_set('Europe/Rome');
class service {
	var $conn=NULL;
	var $servername = "localhost:3306";
	var $username = "emeraldl_emeraldl";
	var $password = "Liner2@root";
	var $dbname = "emeraldl_liner2";
	var $newn=0;
  function __construct() {
	$this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
	if ($this->conn->connect_error) {
	  die("Connection failed: " . $this->conn->connect_error);
	}
    $stmt=$this->conn->prepare("SET time_zone ='-06:30'");
	$stmt->execute();
  }
  function off_service_session($sid){
	$tod=date("Y-m-d");
	$stmt=$this->conn->prepare("update qsession set timeoff=CURRENT_TIMESTAMP,state='off' where  sid=? and timeon like '".$tod."%'  ");
	$stmt->bind_param("s",  $sid);
	$re=$stmt->execute();
	if ($re) {
		echo 1;
	}else{
		echo 0;
	}
	$stmt->close();
	$this->conn->close();
  }
  function start_service_session($sid){
	$tod=date("Y-m-d H");
	$qsid=md5($tod.'on'.$sid);
	$state='on';
	$stmt=$this->conn->prepare("insert into qsession (qsid,state,sid) values(?,?,?) ");
	$stmt->bind_param("sss",  $qsid,$state,$sid);
	$re=$stmt->execute();
	if ($re) {
		echo 1;
	}else{
		echo 0;
	}
	$stmt->close();
	$this->conn->close();
  }
function get_service_session( $sid){
	$tod=date("Y-m-d");//echo "select distinct(qsid) as qsid,timeon,timeoff,state from qsession where sid='$sid' and issue_time like '".$tod."%'  ";
	$stmt=$this->conn->prepare("select distinct(qsid) as qsid,timeon,timeoff,state from qsession where sid=? and timeon like '".$tod."%'  ");
	$stmt->bind_param("s",  $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$number=0;
	$stmt->close();
	$this->conn->close();
	$row = $result->fetch_assoc();
	if ($row['state']=='on') {
		return $row['timeon'];
	}else{
		return "Not started. Please try later.";
	}
}
function get_total_queue_byservice($sid){
	$tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select count(qid) as total from queue where sid=? and state!='checkedin' and status!='blocked'  and issue_time like '$tod%' ");
	$stmt->bind_param("s", $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_assoc();
	$stmt->close();
	$this->conn->close();
	return ($row);
  
}
function get_current_queue_byservice($sid){
	$tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select min(number) as current from queue where sid=? and state!='checkedin'  and status!='blocked'  and issue_time like '$tod%'  ");
	$stmt->bind_param("s", $sid);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_assoc();
	$stmt->close();
	$this->conn->close();
	return ($row);
  
}
function get_queue_detail_byservice($sid){
	$tod=date("Y-m-d");
	$stmt = $this->conn->prepare("select distinct(qid) as qid,token,issue_time,number from queue where sid=? and state!='checkedin'  and status!='blocked'  and issue_time like '$tod%' order by issue_time asc, number asc ");
	$stmt->bind_param("s", $sid);
	$stmt->execute();
	$svs=array();
	$result = $stmt->get_result();
	while ($row = $result->fetch_assoc()) {
		$svs[]=$row;
	}
	$stmt->close();
	return $svs;
  }
}