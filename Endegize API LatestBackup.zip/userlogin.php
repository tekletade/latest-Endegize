<?php
session_start();

?>
<?php

include('includes/config.php');


if(isset($_POST['login']))
{
    $email=$_POST['email'];
    $password=$_POST['password'];
	

    $check_user="select * from users WHERE email='$email' AND password='$password'";

 
    $run=mysqli_query($con,$check_user);

    if(mysqli_num_rows($run))
    {
	 echo "<script>alert('You're successfully login!')</script>";
       
 echo "<script>window.open('logged.php','_self')</script>";
       
$_SESSION['email']=$email;



    }
    else
    {
        echo "<script>alert('Email or password is incorrect!')</script>";
		  echo "<script>window.open('index.php','_self')</script>";
		
		 exit();
		
    }
}
?>